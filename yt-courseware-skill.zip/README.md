# yuketang-courseware

雨课堂（长江雨课堂）课件抓取工具，作为一个可移植的 Agent **Skill** 使用：复用本机已登录的 Edge 会话，导出某门课全部课堂课件，生成按课次排列的 PDF、逐页 OCR 文字和目录索引。

> **仅限个人学习使用**。课件版权归授课教师与学校所有，请不要公开传播抓取产物；公开仓库中不要提交 `cookies.json`、`slides/`、`教案PDF/`。

## 为什么这么做

雨课堂的课件不在公开网页里：必须先微信扫码登录，页面是 SPA，幻灯片是带签名的 CDN 图片，而且没有 PPTX 原文件可下载。所以工具链是：

1. 用独立配置启动 Edge 并打开调试端口（CDP）——不碰用户日常浏览器配置；
2. 用户在窗口里手动扫码登录——脚本不处理登录，也不接触账号密码；
3. 通过 CDP 读取登录后的 cookie，在页面同源上下文里调用雨课堂内部接口拿到课次、课件、幻灯片列表；
4. 直接下载带 `auth_key` 的图片（签名 URL，不需要额外鉴权）；
5. Pillow 合并 PDF；Windows 自带 OCR 生成文字；脚本生成索引。

详细原理见 [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)，发布到 GitHub 的步骤见 [docs/PUBLISH.md](docs/PUBLISH.md)。

## 环境要求

- Windows 10/11，Microsoft Edge
- Node.js ≥ 18（使用全局 `fetch`、`WebSocket`）
- Python ≥ 3.9 + Pillow
- 能正常扫码登录雨课堂

## 安装

### 方式一：安装为 Agent Skill

把整个目录复制（或软链接）到 Agent 的技能目录：

```powershell
# DSH（DeepSeek Harness）
Copy-Item -Recurse . "$env:USERPROFILE\.dsh\skills\yuketang-courseware"

# Claude Code
Copy-Item -Recurse . "$env:USERPROFILE\.claude\skills\yuketang-courseware"

# Codex
Copy-Item -Recurse . "$env:USERPROFILE\.agents\skills\yuketang-courseware"
```

重启/刷新 Agent 后，技能会按 `SKILL.md` 里的 description 被自动路由。

### 方式二：直接当命令行脚本用

```bash
node scripts/cdp.js --help
node scripts/scrape.js <classroom_id> <输出目录>
```

## 快速开始

```powershell
# 1. 启动带调试端口的 Edge（独立 profile）
$edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
Start-Process $edge -ArgumentList @(
  "--remote-debugging-port=9222", "--remote-allow-origins=*",
  "--user-data-dir=$PWD\edge-profile",
  "https://changjiang.yuketang.cn/v2/web/index"
)

# 2. 在弹出的窗口里微信扫码登录，然后：
node scripts/cdp.js eval "location.href"   # 确认已登录
node scripts/cdp.js cookies                # 写 cookies.json

# 3. 抓取（classroom_id 从课程学习日志页 URL 里取）
node scripts/scrape.js 26109207 "out/雨课堂-概率论"

# 4. 合并 PDF
python scripts/build_pdf.py "out/雨课堂-概率论"

# 5. 可选：OCR + 索引
python scripts/list_images.py "out/雨课堂-概率论" > ocr_list.txt
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/ocr.ps1 -ListFile ocr_list.txt -OutFile ocr.tsv
python scripts/ocr_to_text.py ocr.tsv "out/雨课堂-概率论/OCR文本"
python scripts/build_index.py "out/雨课堂-概率论"
```

## 目录结构

```
yuketang-courseware/
├── SKILL.md                 # 技能定义（Agent 读取）
├── README.md
├── LICENSE                  # MIT
├── .gitignore
├── docs/ARCHITECTURE.md     # 原理与接口说明
└── scripts/
    ├── cdp.js               # CDP 客户端（eval / cookies / nav / click / shot）
    ├── scrape.js            # 课堂记录 → 课件 → 幻灯片 → 下载
    ├── build_pdf.py         # 幻灯片合并为按课次 PDF
    ├── list_images.py       # 生成 OCR 图片清单
    ├── ocr.ps1              # Windows OCR（Windows.Media.Ocr）
    ├── ocr_to_text.py       # OCR 结果汇总为逐课件文本
    └── build_index.py       # 生成目录索引
```

## 已知限制

- 只导出**课件图片**，没有 PPTX 原文件（雨课堂本身不提供）。
- 图片是渲染后的 JPG，长边约 1600px；文字密集型公式页 OCR 可能有误差。
- 内部接口随站点改版可能失效，需要按 `docs/ARCHITECTURE.md` 重新抓包核对。
- 浏览器进程在受限沙箱里可能无法启动；需要宿主提升权限，或由用户手动启动 Edge。

## License

MIT，见 [LICENSE](LICENSE)。
